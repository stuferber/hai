const gulp = require('gulp');
const sass = require('gulp-dart-sass');
const autoprefixer = require('gulp-autoprefixer');
const uglify = require('gulp-uglify');
const rename = require('gulp-rename');
const concat = require('gulp-concat');
const notify = require('gulp-notify');
const browserSync = require('browser-sync').create();
const cleanCSS = require('gulp-clean-css');
const postcss = require('gulp-postcss');
const assets  = require('postcss-assets');


const themeName = 'hai';
const output = './app/public/wp-content/themes/';
const outputDir = output + themeName + '/assets/';
const srcDir = './src/';

const config = {
    localURL: themeName + '.local',
    srcSCSS: srcDir + 'scss/main.scss',
    jsOutput: outputDir + 'js/',
    cssOutput: outputDir + 'css/',
    bootstrapPathJS: 'node_modules/bootstrap/dist/js/bootstrap.bundle.js',
    jarallaxPath: 'node_modules/jarallax/dist/jarallax.js',
    granimPath: 'node_modules/granim/dist/granim.js'
};

// Output JS
gulp.task('scripts', function() {
  return gulp.src([config.bootstrapPathJS, config.jarallaxPath, config.granimPath])
    .pipe(concat('scripts.js'))
    .pipe(gulp.dest( config.jsOutput ))
    .pipe(rename({suffix: '.min'}))
    .pipe(uglify())
    .pipe(gulp.dest( config.jsOutput ))
    .pipe(notify({ message: 'Scripts task complete' }));
});

// Compile CSS
gulp.task('compile-styles', function() {
  return gulp.src( config.srcSCSS )
    .pipe(sass({outputStyle: 'expanded'}).on('error', sass.logError))
    .pipe(autoprefixer('last 2 versions'))
    .pipe(gulp.dest( config.cssOutput ))
    .pipe(rename({suffix: '.min'}))
    .pipe(cleanCSS('level: 2'))
    .pipe(gulp.dest( config.cssOutput ))
    .pipe(browserSync.stream())
    .pipe(notify({ message: 'Styles task complete' }));
});

// Process inline SVG
gulp.task('process-styles', function () {
  return gulp.src([ config.cssOutput + 'main.css', config.cssOutput + 'main.min.css'])
    .pipe(postcss([assets({
      loadPaths: ['node_modules/bootstrap-icons/', config.outputDir + 'images/']
    })]))
    .pipe(gulp.dest('.'));
});

// Output CSS
gulp.task('styles', gulp.series('compile-styles', 'process-styles'));

// Serve
gulp.task('serve', function() {

  browserSync.init({
      proxy: config.localURL
  });

  gulp.watch(['./src/scss/**/*.scss', '!./node_modules/', '!./.git/'], gulp.series('compile-styles', 'process-styles'));

  gulp.watch(['./**/*.*', '!./node_modules/', '!./.git/', '!./**/*.scss', '!./main.css', '!./main.min.css']).on('change', browserSync.reload);
  
});

// Watcher
gulp.task('watch', function() {
  gulp.watch(['./**/*.scss', '!./node_modules/', '!./.git/'], gulp.series('compile-styles', 'process-styles'));
});